public class TiposPrimitivos {

    public static void main(String[] args) {
        char sexo = 'f';
        byte idade = 89;
        short codigo = 256;
        float nota = 9.4f;
        int alunos = 100, classes = 10;
        long habitantes = 55000;
        double dolar = 4.70;
        boolean alternativa = false;

        System.out.println("Sexo: " + sexo + " / " + "Idade: " + idade+ " / " + "Código: " + codigo);
        System.out.println("Nota: " + nota+ " / " + "Alunos: " + alunos + " / " + "Classes: " + classes);
        System.out.println("Habitantes: " + habitantes + " / " + "Dolar: " + dolar + " / " + "Alternativa: " + alternativa);
    }
}
